# SS_Flow Training Metrics Snapshot

- output_root: `/mnt/sda2/hef/Base/SS_Flow-SLat_Flow_v3/outputs/phase2/foundation`
- report_dir: `outputs/reports/phase`

| Stage | Records | Step | Loss | Global Batch | Key Control Metric |
|---|---:|---:|---:|---:|---|
| stage1_geoss | 509 | 509 | 3.27161 | 24 | confidence_mean=0.597501 |
| stage2_ss_velocity | 3612 | 3612 | 0.593467 | 28 | confidence_mean=0.295885 |

## Generated Figures
- `outputs/reports/phase/stage1_geoss/stage1_geoss_losses.png`
- `outputs/reports/phase/stage1_geoss/stage1_geoss_quality.png`
- `outputs/reports/phase/stage2_ss_velocity/stage2_ss_velocity_losses.png`
- `outputs/reports/phase/stage2_ss_velocity/stage2_ss_velocity_quality.png`
- `outputs/reports/phase/overview_loss.png`
- `outputs/reports/phase/overview_confidence_visibility.png`
